<!DOCTYPE HTML>
<html>
<head>
	<meta charset="UTF-8">
	<meta content="yes" name="apple-mobile-web-app-capable"/>
	<meta content="black" name="apple-mobile-web-app-status-bar-style"/>
	<meta name="format-detection" content="telephone=no"/>
	<meta content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no" name="viewport"/>
	<title>祈福</title>
	<style type="text/css">		
		body{color:#505050;font-size:30px; font-family:"Microsoft YaHei"; line-height:1.5; background:url(img/bg02.jpg) no-repeat; background-size:100% auto;}		
		html,body,h1,h2,h3,p,div,ul,li{margin:0;padding:0;}
		ul,li{list-style:none;}
		html,body,img{border:0;}
		em{font-style:normal;}			
		h1,h2,h3,strong,em{ font-style:normal; font-weight:normal;}
		a,a:hover{text-decoration:none; display:inline-block; outline:none;blr:expression(this.onFocus=this.blur());}
		.clearfix:after{clear:both; content:'.'; display:block; visibility:hidden; height:0}		
		.container{width:100%;}		
		
		.msg{ margin:0 10px 0 20px; padding-top:40%;}		
	    .msginfo{ width:100%; line-height:1.5; font-size:1.1rem; color:#FFF;}
		.info{ width:100%; padding-top:20px; text-indent:32px; line-height:1.5; font-size:1.1rem; color:#FFF;}
		.infonum{ width:90%; position:absolute; bottom:26%; left:5%; text-align:center; line-height:1.5; font-size:1.1rem; color:#f6e90e;}		
		.btn{ width:60%; position:absolute; bottom:10%; left:20%;}	
		.btn a{ width:100%; display:block; height:40px; line-height:40px; text-align:center; color:#873600; font-size:1.1rem; background:#FFF; border-radius:3px;}	
    .aa{ width:100%; position:fixed; top:0; left:0; height:72px; z-index:2;}
    .aa .bb{ width:100%; max-width:640px; margin:0 auto; height:100%; font-size:50%; position:relative;}
    .aa .bb .lt{ width:20%; max-width:72px; height:100%; position:absolute; top:0; left:2%; text-align:left;}
    .aa .bb .lt img{ width:100%; max-width:72px; vertical-align:middle;}
    .aa .bb .ct{ padding:0 32% 0 22%; height:100%; color:#FFF; text-align:center;font-size: 10px;}
    .aa .bb .rt{ width:30%; height:100%; max-width:160px; position:absolute; top:0; right:10%; text-align:right;}
    .aa .bb .rt .btn{ width:100%; display:inline-block; padding:6% 0; color:#FFF; text-decoration:none; text-align:center; border-radius:5px; background:#399B39; font-size:15px;}
		
    </style>
</head>
<body>





<!--编辑区域 start-->
<div class="msg" id="stepOne">
	<div class="msginfo">送上你的祈福</div>
</div>
<div class="infonum margintop2">为灾区祈福<br>已有5445993位变态小游戏用户为灾区祈福</div> </div> 
<div class="btn">
    <a href="index.php.html">我也要祈福</a>
</div>
<!--编辑区域 end-->
<div class="aa">
    <div class="bb">
        <div class="rt">
            <table width="100%" height="100%" border="0">
              <tr>
                <td align="center" valign="middle"><a href="http://mp.weixin.qq.com/s?__biz=MzA4NTk2MzgxNg==&mid=200512824&idx=1&sn=fb2c29f97e981c8eb672d9e733750b96#rd" class="btn">关注我</a></td>
              </tr>
            </table>
        </div>
    </div>
</div>
<img src="http://c.cnzz.com/wapstat.php?siteid=1252958148&r=&rnd=1293620507" width="0" height="0"/></body>
</html>
