[
    [
        {"text" : "开源", "textColor":"0xF1C40F"},
        {"text" : "，", "textColor":"0xFFFFFF"},
        {"text" : "免费", "textColor":"0xF1C40F"},
        {"text" : "，", "textColor":"0xFFFFFF"},
        {"text" : "跨平台", "textColor":"0xF1C40F"}
    ],
    [
        {"text" : "推动", "textColor":"0xFFFFFF"},
        {"text" : "游戏", "textColor":"0xF1C40F"},
        {"text" : "前行", "textColor":"0xFFFFFF"}
    ],
    [
        {"text" : "HTML5", "textColor":"0xF1C40F"},
        {"text" : "游戏框架", "textColor":"0xFFFFFF"}
    ]
]