dataForWeixin.appId = "wx8820cdf5db680ffa";
dataForWeixin.url = "http://game.vbaitong.com/index.html?"+_con["num"]+"/";
